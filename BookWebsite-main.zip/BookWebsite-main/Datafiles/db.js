npm install
node app.js
Execute Node.js

