<meta charset="UTF-8">    
<meta name="viewport" content="width=device-width, initial-scale=1.0>
<meta name="description content="Free online books from all genres">
<meta name="keywords" content="Books, Chapters, Genre, Authors">
<meta name="author" content="Simon Mahon, Atasi Muppala, Christian Timofti">
<meta name="Keywords" content="adventure, women, men, children, europe, china, spain
anime, japanese, manga, horror, anime, love, romance, murder, death, mystery, 
science fiction, narrtive, fairy tale, philoshopy, crime, fantasy, dystopian",
<meta http-equiv="refresh" content="30">
<link rel="stylesheet" href="main.scss">